//
//  ViewController.swift
//  2022
//
//  Created by Swapnil Sahare on 11/01/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
   
    var authorArrey : [API] = [.authors]
    
    @IBOutlet weak var urlTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        urlTableView.delegate = self
        urlTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authorArrey.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = urlTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let apiType : API = authorArrey[indexPath.row]
        cell.textLabel?.text = apiType.rawValue
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urlApi : API = authorArrey[indexPath.row]
        self.performSegue(withIdentifier: "Response", sender: urlApi)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response"{
            guard let api : API = sender as! API? else {return}
            var targetVC = segue.destination as! ConnectionManagerDelegate
            targetVC.api = api
        }
    }
}
