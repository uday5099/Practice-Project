//
//  AuthorModel.swift
//  2022
//
//  Created by Swapnil Sahare on 11/01/23.
//

import Foundation

struct Author : Codable {
    var authors : [String]?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.authors, forKey: .authors)
    }
    enum CodingKeys: CodingKey {
        case authors
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.authors = try container.decodeIfPresent([String].self, forKey: .authors)
    }
}
