//
//  PoemViewController.swift
//  2022
//
//  Created by Swapnil Sahare on 11/01/23.
//

import UIKit

class PoemViewController: UIViewController, UITextViewDelegate {
    var poem : String?
    
    @IBOutlet weak var poemTextView : UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        poemTextView.delegate = self
        poemTextView.text = poem?.description
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
