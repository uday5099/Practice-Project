//
//  PostModel.swift
//  SocialMediaPostApi
//
//  Created by Uday Patil on 20/01/23.
//

import Foundation
