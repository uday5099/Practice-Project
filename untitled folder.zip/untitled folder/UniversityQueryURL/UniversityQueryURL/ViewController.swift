//
//  ViewController.swift
//  UniversityQueryURL
//
//  Created by Uday Patil on 11/01/23.
//

import UIKit

class ViewController: UIViewController {

    var universityDetails : [University]?
    
    let baseUrl = "http://universities.hipolabs.com/search"
    let urlQuery = "country=India&state_province=Dehradun"
    
    @IBOutlet weak var MainTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        MainTableView.dataSource = self
        MainTableView.delegate = self
        AllUniData()
    }
    func AllUniData(){
        var allInfo: [University]?

        let url = URL(string: baseUrl)
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { (data, responce, error) in
            if error == nil {
                let receivedData = data
            }else {
                print("Error :\(error?.localizedDescription ?? "There is Error Found")")
            }
            do{
                allInfo = try JSONDecoder().self.decode([University]?.self, from: data!)
               // print(allInfo ?? "")
                self.universityDetails = allInfo
                DispatchQueue.main.async {
                    self.MainTableView.reloadData()
                }
            }catch{
                print("Error : -\(error)")
            }
        }
        task.resume()
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universityDetails?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainCell", for: indexPath)
       
        let university: University = universityDetails![indexPath.row]
        
        cell.textLabel?.text = university.name
        
        return cell
    }
}
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        MainTableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "FirstResponse", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "FirstResponse"){
            let vc = segue.destination as! SecondViewController
            vc.receivedQueryUrl = urlQuery
        }
    }
}
