//
//  SecondViewController.swift
//  UniversityQueryURL
//
//  Created by Uday Patil on 11/01/23.
//

import UIKit

class SecondViewController: UIViewController {
    
    var universityDetails : [University]?
    var receivedQueryUrl: String?
    
    var sendingData: String? = ""
    var allQuerydetail: [University]?
    
    @IBOutlet weak var SecondResponseTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        SecondResponseTableView.dataSource = self
        SecondResponseTableView.delegate = self
        AllUniData()
    }
    func AllUniData(){
//        print("Get Data is Working ")
        let url = URL(string: "https://datausa.io/api/data?\(receivedQueryUrl!)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { (data, responce, error) in
            
            if error == nil {
                let receivedData = data
//                print(receivedData ?? "Received Our Data")
            }else {
                print("Error :\(error?.localizedDescription ?? "There is Error Found")")
            }
            do{
                self.allQuerydetail = try JSONDecoder().self.decode([University].self, from: data!)
                print(self.allQuerydetail ?? "")
                self.allQuerydetail = self.universityDetails
                DispatchQueue.main.async {
                    self.SecondResponseTableView.reloadData()
//                    print("Data is receiving")
                }
            }catch{
                print("Error : -\(error)")
            }
        }
        task.resume()
    }
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

extension SecondViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return universityDetails?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SecondCell", for: indexPath)
       
        let university: University = (universityDetails![indexPath.row])
       
        cell.textLabel?.text = university.country
        cell.detailTextLabel?.text = university.stateProvince
        return cell
    }
}
extension SecondViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        SecondResponseTableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "SecondResponse", sender: self)
    
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "SecondResponse"){
            
           let thirdvc =  segue.destination as! ThirdViewController
            thirdvc.receivedData = sendingData
        }
    }
}
