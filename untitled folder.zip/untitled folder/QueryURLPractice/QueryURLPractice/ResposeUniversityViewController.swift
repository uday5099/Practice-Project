//
//  ResposeUniversityViewController.swift
//  QueryURLPractice
//
//  Created by Uday Patil on 10/01/23.
//

import UIKit

class ResposeUniversityViewController: UIViewController, ConnectionManagerDelegate {
    var api: GivenApi?
    
    func finishTaskWithResponse(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else { return }
            do{
                let decoder = JSONDecoder()
                self.responsedata = try decoder.decode([University].self, from: data)
            }catch let err{
                print(err)
            }
        }
    }
    
    var responsedata : [University]?
    @IBOutlet weak var ResponseTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
      // ResponseTableView.dataSource = self        
    }
    
    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
//extension ResposeUniversityViewController : UITableViewDataSource, UITableViewDelegate {
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        <#code#>
//    }
//
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        <#code#>
//    }
//
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        <#code#>
//    }
//
//}
