//
//  ViewController.swift
//  QueryURLPractice
//
//  Created by Uday Patil on 10/01/23.
//

import UIKit

class ViewController: UIViewController ,ConnectionManagerDelegate {
    var api: GivenApi?
    
    func finishTaskWithResponse(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else { return }
            let decoder = JSONDecoder()
            do{
                self.UniversityData = try? decoder.decode([University]?.self, from: data)
            } catch let err {
                print(err)
            }
            DispatchQueue.main.async {
                self.firstTableView.reloadData()
            }
        }
    }
    var UniversityData : [University]?
    let manager = ConnectionManager()
    //var university : [GivenApi] = [.university]
    
    @IBOutlet weak var firstTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstTableView.delegate = self
        firstTableView.dataSource = self
        manager.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        manager.sesionStart()
    }
}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return UniversityData?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath)
        let university: University = UniversityData![indexPath.row]
        cell.textLabel?.text = university.country

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let urlApi : University = UniversityData![indexPath.row]
        
        performSegue(withIdentifier: "Response", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Response" {
            guard let api: GivenApi = sender as! GivenApi? else { return }
            var targetVc = segue.destination as? ConnectionManagerDelegate
            targetVc?.api = api
            
        }
    }
}
