//
//  Connection.swift
//  QueryURLPractice
//
//  Created by Uday Patil on 10/01/23.
//

import Foundation
protocol ConnectionManagerDelegate {
    var api : GivenApi?  {get set}
    func finishTaskWithResponse(data:Data?, error:Error?)
}

enum GivenApi : String {
    case university = "http://universities.hipolabs.com/search"
   // case countryStateProvince = "country=India&stateprovince=Dehradun"
}

class ConnectionManager {
    var delegate : ConnectionManagerDelegate?
    
    private let startSession = URLSession.shared
    var url : String?
    
    init(){
    }
    
    func sesionStart(){
        guard let delegate = delegate,
              let api = delegate.api else {return}
        let url = api.rawValue
        self.urlHit(url: url)
    }
    
    func urlHit(url: String) {
        guard let myUrl = URL(string: url) else { return }
        let request = URLRequest(url:myUrl)
        startSession.dataTask(with: request) { data, response, error in
            guard let delegate = self.delegate else {
                return
            }
            delegate.finishTaskWithResponse(data: data, error: error)
        }.resume()
    }
}


