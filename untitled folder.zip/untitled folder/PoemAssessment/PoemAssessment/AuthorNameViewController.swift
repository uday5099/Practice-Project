//
//  AuthorNameViewController.swift
//  PoemAssessment
//
//  Created by Uday Patil on 12/01/23.
//

import UIKit

class AuthorNameViewController: UIViewController {

    @IBOutlet weak var DetailTableView: UITableView!
    
    var name : String?
    var NameArray : [Poem]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        allAuthorsData()
        
        DetailTableView.dataSource = self
        DetailTableView.delegate = self
    }
    func allAuthorsData(){
        
          var urlStr = "https://poetrydb.org/author/"
        //append query parameter on URL with ?
          let query = name?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
          urlStr.append(query)

          let url = URL(string: urlStr)
          let request = URLRequest(url: url!)
        
          let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
              guard let data = data else {return}
              do {
                  self.NameArray = try JSONDecoder().decode([Poem].self, from: data)
              }catch let err{
                  print(err)
              }
              DispatchQueue.main.async {
                  self.DetailTableView.reloadData()
              }
          }
          dataTask.resume()
      }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension AuthorNameViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
          return NameArray?.count ?? 0
      }

      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
          let cell = DetailTableView.dequeueReusableCell(withIdentifier: "PoemCell", for: indexPath)
          
          let detail : Poem = NameArray![indexPath.row] //Poem Array IndexPath ,all values inside poem array
          
          // to access single value from deictionary
          //let detail = dictName[.keyname]

          cell.textLabel?.text = detail.author
          cell.detailTextLabel?.text = detail.title

          return cell
      }

      func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
          let titleArrey : Poem = NameArray![indexPath.row]
          let poem: [String] = titleArrey.lines ?? [""]
          self.performSegue(withIdentifier: "DetailResponse", sender: poem)//what to perform
      }

      override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          if segue.identifier == "DetailResponse" {
              
              let detailPoemVC = segue.destination as! DetailPoemViewController
              let poemLines = sender as! [String] //what  datatype of that property to send on next VC
              
              detailPoemVC.fullPoem = poemLines.joined(separator:",")
          }

      }
}
