//
//  AuthorModel.swift
//  PoemAssessment
//
//  Created by Uday Patil on 12/01/23.
//

import Foundation

struct PoemAuthor : Codable {
    var authors : [String]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.authors, forKey: .authors)
    }
    enum CodingKeys: String, CodingKey {
        case authors
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.authors = try container.decodeIfPresent([String].self, forKey: .authors)
    }
}
