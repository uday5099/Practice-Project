//
//  ViewController.swift
//  PoemAssessment
//
//  Created by Uday Patil on 12/01/23.
//

import UIKit

class ViewController: UIViewController, ConnectionManagerDelegate {
    var api: API?
    
    func finishTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async{
            self.removeLoading()
        }
        if error == nil {
            guard let data = data else { return }
            let decoder = JSONDecoder()
            do{
                self.authorData = try? decoder.decode(PoemAuthor?.self, from: data)
            } catch let err {
                print(err)
            }
            DispatchQueue.main.async {
                self.AuthorNameList.reloadData()
            }
        }
    }
    
    var authorData : PoemAuthor? //dictionary of poem authors
    let manager = ConnectionManager()
    var authors = [String]()//array of authors
    
    
    @IBOutlet weak var AuthorNameList: UITableView!
    
    //var searching : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        api = .authorName  //Enum case
        
        AuthorNameList.dataSource = self
        AuthorNameList.delegate = self
        view.backgroundColor = .brown
        
        manager.delegate = self // Connection Class delegate
       
//      self.searchBar.delegate = self //searchBar
 //     self.searchBar.showsCancelButton = true
    }

    override func viewDidAppear(_ animated: Bool) {
        manager.sessionStart()
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      //  if searching {
            return authorData?.authors?.count ?? 0
     //   }
     //   return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AuthorCell", for: indexPath)
       // if searching {
            let author  = authorData?.authors?[indexPath.row]
            
            cell.textLabel?.text = author
            cell.backgroundColor = .white
            
            return cell
       // }
     //   return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
       // if searching {
            let singleAuthor = authorData?.authors?[indexPath.row]
            performSegue(withIdentifier: "AuthorResponse", sender: singleAuthor)
    //    }
      //  self.searchBar.searchTextField.endEditing(true)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AuthorResponse" {
            let target = segue.destination as! AuthorNameViewController
            target.name = (sender as? String) ?? ""
        }
    }
//

}



