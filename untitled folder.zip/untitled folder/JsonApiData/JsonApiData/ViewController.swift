//
//  ViewController.swift
//  JsonApiData
//
//  Created by Uday Patil on 02/01/23.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
   
    // API in an array
    let apiArray: [API] = [.coinpaprika,.musicbrains]
    
    
    @IBOutlet weak var JsonTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.JsonTable.dataSource = self
        self.JsonTable.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apiArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ApiDataCell")
        let api: API = apiArray[indexPath.row]
        cell?.textLabel?.text = api.rawValue
        
        return cell!
    }
    
    // delegate method
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let api: API = apiArray[indexPath.row] 
        
        switch(api){
        case .coinpaprika:
            self.performSegue(withIdentifier: "CoinPaprikaAPI", sender: api)
        case .musicbrains:
            self.performSegue(withIdentifier: "MusicBrainsAPI", sender: api)
       
        }
    }
    
    //segue....for navingation.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier?.hasSuffix("API") == true {
            guard let api: API = sender as? API else {return}
            var targetVc = segue.destination as? ConnectionManagerDelegate
            targetVc?.api = api
        }
    }
    
}





