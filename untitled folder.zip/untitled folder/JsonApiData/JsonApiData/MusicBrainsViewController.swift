//
//  MusicBrainsViewController.swift
//  JsonApiData
//
//  Created by Uday Patil on 02/01/23.
//

import UIKit

class MusicBrainsViewController: UIViewController, ConnectionManagerDelegate {
    
    func didCompleteTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async {
            self.musicBrainsLoadingView.isHidden = true
            self.musicBrainsLoadingIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
        if error == nil {
            guard let data = data else {
                return
            }
            let text = String(data: data, encoding: .utf8)
            DispatchQueue.main.async {
                self.MusicBrainsApiView.text = text
            }
        }
        else {
            DispatchQueue.main.async {
                self.MusicBrainsApiView.text = "Error"
            }
        }
    }
    
    var api: API?
    let manager = ConnectionManager()
    
    @IBOutlet weak var MusicBrainsApiView: UITextView!
    @IBOutlet weak var musicBrainsLoadingView: UIView!
    @IBOutlet weak var musicBrainsLoadingIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.manager.delegate = self
        self.MusicBrainsApiView.text = self.api?.rawValue
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.manager.startSession()
        
        musicBrainsLoadingView.isHidden = false
        musicBrainsLoadingIndicator.startAnimating()
        self.view.isUserInteractionEnabled = false
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
