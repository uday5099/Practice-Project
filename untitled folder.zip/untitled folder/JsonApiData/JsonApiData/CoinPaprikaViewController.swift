//
//  CoinPaprikaViewController.swift
//  JsonApiData
//
//  Created by Uday Patil on 04/01/23.
//

import UIKit

class CoinPaprikaViewController: UIViewController, ConnectionManagerDelegate {
    func didCompleteTaskWithResponse(data: Data?, error: Error?) {
        
        DispatchQueue.main.async {
            self.coinPaprikaLoadingView.isHidden = true
            self.coinPaprikaLoadingIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
        if error == nil {
            guard let data = data else {
                return
            }
            let text = String(data: data, encoding: .utf8)
            DispatchQueue.main.async {
                self.coinPaprikaView.text = text
            }
        }
        else {
            DispatchQueue.main.async {
                self.coinPaprikaView.text = "Error"
            }
        }
    }
    var api: API?
    
    @IBOutlet weak var coinPaprikaView: UITextView!
    @IBOutlet weak var coinPaprikaLoadingView: UIView!
    @IBOutlet weak var coinPaprikaLoadingIndicator: UIActivityIndicatorView!
    
    let manager = ConnectionManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.manager.delegate = self
        self.coinPaprikaView.text = self.api?.rawValue
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.manager.startSession()
        
        coinPaprikaLoadingView.isHidden = false
        coinPaprikaLoadingIndicator.startAnimating()
        self.view.isUserInteractionEnabled = false
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
