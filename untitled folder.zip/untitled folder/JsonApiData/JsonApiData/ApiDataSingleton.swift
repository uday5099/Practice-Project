//
//  ApiDataSingleton.swift
//  JsonApiData
//
//  Created by Uday Patil on 02/01/23.
//

import Foundation

//Protocol
protocol ConnectionManagerDelegate {
    var api: API? {get set}
    
    func didCompleteTaskWithResponse(data: Data?, error: Error?)
}

// RawValues
enum API : String {
    
    case coinpaprika = "https://api.coinpaprika.com/v1/coins/btc-bitcoin"
    case musicbrains = "https://musicbrainz.org/ws/2/artist/5b11f4ce-a62d-471e-81fc-a69a8278c7da?fmt=json"
}

// Singleton class
class ConnectionManager {
    
    var delegate: ConnectionManagerDelegate?
    private let session = URLSession.shared   //Connectionmanager.shared   .....used in any class throghout the App
    var url: String?
    
    init(){
        }
    
    func startSession() {
        guard let delegate = delegate,
              let api = delegate.api else {return}
        let url = api.rawValue
        self.hitUrl(Url: url)
    }
    
    private func hitUrl(Url: String) {
        print(Url)
        
        guard let myUrl = URL(string: Url) else { return }
        let request = URLRequest(url: myUrl)
        
        session.dataTask(with: request, completionHandler: { data, response, error in
            
            guard let delegate = self.delegate else {
                return
            }
            delegate.didCompleteTaskWithResponse(data: data, error: error)
        }).resume()
    }
}

