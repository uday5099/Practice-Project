//
//  ViewController.swift
//  TabBar
//
//  Created by Uday Patil on 24/01/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var sampleView : UIView!
    
    @IBOutlet weak var redLabel: UILabel!
    
    @IBOutlet weak var greenLabel: UILabel!
    
    
    @IBOutlet weak var bluelabel: UILabel!
    
    var redColorFloatValue: CGFloat = 0
    var greenColorFloatValue: CGFloat = 0
    var blueColorFloatValue: CGFloat = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // UpdateColor()
    }
    @IBAction func SegmentAction(_ sender : Any){
        guard let segment = sender as? UISegmentedControl else { return }
        
        switch segment.selectedSegmentIndex {
        case 0:
            self.sampleView.backgroundColor = UIColor.red
        case 1:
            self.sampleView.backgroundColor = UIColor.green
        case 2:
            self.sampleView.backgroundColor = UIColor.blue
        default:
            print("OK")
        }
       
    }

    func UpdateColor(){
        let color =  UIColor(red: redColorFloatValue/255.0, green: greenColorFloatValue/255.0, blue: blueColorFloatValue/255.0, alpha: 1)
        self.sampleView.backgroundColor = color
        
    }
    
    @IBAction func GetStepper(_ sender: Any) {
        guard let button = sender as? UIStepper else { return }
        
        switch button.tag {
        case 0 :
            self.redColorFloatValue = button.value
            self.redLabel.text = "\(button.value)"
            break
        case 1 :
            self.greenColorFloatValue = button.value
            self.greenLabel.text = "\(button.value)"
            break
        case 2 :
            self.blueColorFloatValue = button.value
            self.bluelabel.text = "\(button.value)"
            break
        default :
            print("Stepper")
        }
        UpdateColor()
    }
    
    @IBAction func Slide(_ sender: Any) {
        guard let slider = sender as? UISlider else { return }
        
        switch slider.tag {
        case 0 :
            self.redLabel.text = "\(slider.value)"
            self.redColorFloatValue = CGFloat(slider.value)
        case 1 :
            self.greenLabel.text = "\(slider.value)"
            self.greenColorFloatValue = CGFloat(slider.value)
        case 2 :
            self.bluelabel.text = "\(slider.value)"
            self.blueColorFloatValue = CGFloat(slider.value)
        default:
            print("Slider Change")
        }
        UpdateColor()
    }
}

