//
//  ViewController.swift
//  TableViewPractice1
//
//  Created by Uday Patil on 16/12/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var myTableView: UITableView!
    
    var myDictArray :[[[String:String]]] = [[["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]],[["E":"Akash"],["F":"Amit"],["G":"Amol"],["H":"Sameer"]],[["I":"Nagpur"],["J":"Mumbai"],["K":"Pune"],["L":"Nashik"],["M":"Solapur"]],[["1":"A"],["2":"B"],["3":"C"]]]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        myTableView.dataSource = self
        myTableView.delegate = self
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return myDictArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let keys = myDictArray[section]

        return keys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "myTableViewCell")

              let rowArray = myDictArray[indexPath.section]
              //print(rowArray) [["A":"Swapnil"],["B":"Sagar"],["C":"Suraj"],["D":"Shubham"]]

              let row = rowArray[indexPath.row]
              //print(keys) ["A":"Swapnil"]

              let key1 = Array(row.keys)[0]
              print(key1)

              let value1 = row[key1]!
              print(value1)

              cell?.textLabel?.text = "\(key1), \(value1)"
              //cell?.detailTextLabel?.text = "\(value1)"

              return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
         return "Section :\(section)"
    }

    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
         return "End :\(section)"
    }

     

}

