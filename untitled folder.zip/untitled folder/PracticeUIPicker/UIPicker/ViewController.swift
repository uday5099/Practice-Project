//
//  ViewController.swift
//  UIPicker
//
//  Created by Uday Patil on 30/01/23.
//

import UIKit

class ViewController: UIViewController {
    
    //step 2 make outlet connection with main
    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    @IBOutlet weak var countryPicker: UIPickerView!
    @IBOutlet weak var countryTextField: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var selectedCountry : String = ""
    var selectedCode : String = ""
    
    var accesoryLabel: UILabel?
    
    var countryList : [Country] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadCountry()
 //       self.countryTextField.delegate = self
//        self.heightConstraint.constant = 0.0
//        self.heightConstraint.isActive = true
        
        self.countryTextField.inputAccessoryView = self.setupToolBar()
        self.countryTextField.inputView = datePicker
       
//        countryPicker.dataSource = self
//        countryPicker.delegate = self
       
       // tapRemovePicker()
    }
    //remove CountryPicker On TAP n SWIPE
    func tapRemovePicker(){
        let tap = UITapGestureRecognizer(target: self, action: #selector(removePicker))
        self.view.addGestureRecognizer(tap)

        let swipe = UISwipeGestureRecognizer(target: self, action: #selector(removePicker))
        swipe.direction = .down
        self.view.addGestureRecognizer(swipe)
    }
    
    @objc func removePicker(){
        self.datePicker.isHidden = true
        self.heightConstraint.constant = 0.0
        self.view.layoutIfNeeded()
    }
    //step 9. done and Cancel button
    @objc func doneButton() {
        self.countryTextField.text = self.accesoryLabel?.text
        self.view.endEditing(true)
    }
    
    @objc func endEditing() {
        self.accesoryLabel?.text = self.countryTextField.text
        self.view.endEditing(true)
    }
    
    //step 8. toolbar on countrypicker and or datePicker
    func setupToolBar() -> UIToolbar {
        let frame = UIScreen.main.bounds
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: 60))
        
        self.accesoryLabel = UILabel(frame: CGRect(x: 0, y: 0, width: frame.size.width/2, height: 40))
        self.accesoryLabel?.adjustsFontSizeToFitWidth = true
        self.accesoryLabel?.minimumScaleFactor = 0.5
        
        let doneBarButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButton))
        
        let space = UIBarButtonItem(systemItem: .flexibleSpace)
        let label = UIBarButtonItem(customView: self.accesoryLabel!)
        
        let cancelBarButton = UIBarButtonItem(title: "cancel", style: .plain, target: self, action: #selector(endEditing))
        
        toolbar.items = [cancelBarButton, label, doneBarButton]
        return toolbar
    }
   
    //step 3 create func to decode data from url
    func loadCountry() {
        guard let url = Bundle.main.url(forResource: "country", withExtension: "json") else { return }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            countryList = try decoder.decode([Country].self, from: data)
        
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.countryPicker.reloadAllComponents()
            }
        }catch let error {
            print(error)
        }
    }
    //step 7. DATE Picker ......use different type of formats in date already given format.
    @IBAction func showDate(_ sender: Any) {
        let date = self.datePicker.date
        let formatter = DateFormatter()
        
        formatter.dateStyle = .medium
        formatter.timeStyle = .medium
        
        var dateString = formatter.string(from: date)
        self.accesoryLabel?.text = dateString
    }
}


//step 4. pickerview DS
extension ViewController: UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return countryList.count
    }
}
//step 5.Pickerview Delegate
extension ViewController: UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let country = countryList[row]
        //step 5 add condition
        if component == 0 {
            return country.name
        }else{
            return country.code
        }
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let country = countryList[row]
        //step 6 Add condition
        if component == 0 {
            selectedCountry = country.name ?? ""
        }else{
            selectedCode = country.code ?? ""
        }
        self.accesoryLabel?.text = "\(selectedCountry) \(selectedCode)"
    }
    
}
//step 6.call textfield delegate
extension ViewController: UITextFieldDelegate {
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
}
     
//step 1 Create Model Of Json
    struct Country : Codable {
        var name : String?
        var code : String?
        
        init(name: String? = nil, code: String? = nil) {
            self.name = name
            self.code = code
        }
        
        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encodeIfPresent(self.name, forKey: .name)
            try container.encodeIfPresent(self.code, forKey: .code)
        }
        
        enum CodingKeys: CodingKey {
            case name
            case code
        }
        
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            self.name = try container.decodeIfPresent(String.self, forKey: .name)
            self.code = try container.decodeIfPresent(String.self, forKey: .code)
        }
    }
    
