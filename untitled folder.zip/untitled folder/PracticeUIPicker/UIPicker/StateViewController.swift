//
//  StateViewController.swift
//  UIPicker
//
//  Created by Uday Patil on 31/01/23.
//

import UIKit

class StateViewController: UIViewController {
    
    @IBOutlet weak var statePicker: UIPickerView!
    
    var stateList : [State] = []
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadState()
        statePicker.dataSource = self
       // statePicker.delegate = self
        // Do any additional setup after loading the view.
    }
    
    //3.Loading State json DATA
    func loadState() {
        guard let url = Bundle.main.url(forResource: "state", withExtension: "json") else { return }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            stateList = try decoder.decode([State].self, from: data)
            
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.statePicker.reloadAllComponents()
            }
        }catch let error {
            print(error)
        }
    }
}
    
extension StateViewController : UIPickerViewDataSource {
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return stateList.count
        }
    }
    
    
    
    //1.Create Model of state json
struct State : Codable {
    var code : String?
    var name : String?
    
    
}
    

