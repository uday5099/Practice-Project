import UIKit

var greeting = "Hello, playground"


for i in 1..<5 {
    
   for j in 1...i {
        print(j, terminator: "")
    }
}

