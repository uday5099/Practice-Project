import UIKit

var greeting = "Hello, playground"

//TREE ....Binary Tree...Node

