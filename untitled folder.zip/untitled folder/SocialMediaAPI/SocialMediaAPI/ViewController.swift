//
//  ViewController.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 14/01/23.
//

import UIKit

class ViewController: UIViewController, ConnectionManagerDelegate {
    var api: API?
    func finishTaskWithResponse(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else { return }
            let decoder = JSONDecoder()
            do{
                self.allUsers = try? decoder.decode([User]?.self, from: data)
            } catch let err {
                print(err)
            }
            DispatchQueue.main.async {
                self.UserListTableView.reloadData()
            }
        }
    }
    
    @IBOutlet weak var UserListTableView: UITableView!
    
    var allUsers : [User]?
    let manager = ConnectionManager()
   // var user = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        api = .users
        manager.delegate = self // Connection Class
        
        UserListTableView.dataSource = self
        UserListTableView.delegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
        manager.sessionStart()
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return allUsers?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath)
        
        let user : User = allUsers![indexPath.row]
        
        cell.textLabel?.text = "\(user.id!)"
       // cell.textLabel?.text = user.name
      cell.detailTextLabel?.text = user.name
        
        cell.textLabel?.font = UIFont.groteskExtraBold(with: 30)
        //cell.textLabel?.font = UIFont.groteskBold(with: 20)
        cell.detailTextLabel?.font = UIFont.groteskMedium(with: 20)

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let user : User = allUsers![indexPath.row]
        UserListTableView.deselectRow(at: indexPath, animated: true)
        performSegue(withIdentifier: "User", sender: user)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "User"){
     
            var targetVC = segue.destination as! UserDetailViewController
//            guard let user : User = sender as? String else {return}
            targetVC.postData = sender as? String
        }
    }
}
