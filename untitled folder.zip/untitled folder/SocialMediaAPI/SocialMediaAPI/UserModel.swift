//
//  UserModel.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 15/01/23.
//

import Foundation

struct User : Codable {
    var id : Int?
    var name : String?
    var userName : String?
    var email : String?
    var address : Address?
    
    var phone : String?
    var website : String?
    var company : Company?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.userName, forKey: .userName)
        try container.encodeIfPresent(self.email, forKey: .email)
        try container.encodeIfPresent(self.address, forKey: .address)
       // try container.encodeIfPresent(self.geo, forKey: .geo)
        try container.encodeIfPresent(self.phone, forKey: .phone)
        try container.encodeIfPresent(self.website, forKey: .website)
        try container.encodeIfPresent(self.company, forKey: .company)
    }
    enum CodingKeys: CodingKey {
        case id
        case name
        case userName
        case email
        case address
     //   case geo
        case phone
        case website
        case company
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decodeIfPresent(Int.self, forKey: .id)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.userName = try container.decodeIfPresent(String.self, forKey: .userName)
        self.email = try container.decodeIfPresent(String.self, forKey: .email)
        self.address = try container.decodeIfPresent(Address.self, forKey: .address)
      //  self.geo = try container.decodeIfPresent(Geo.self, forKey: .geo)
        self.phone = try container.decodeIfPresent(String.self, forKey: .phone)
        self.website = try container.decodeIfPresent(String.self, forKey: .website)
        self.company = try container.decodeIfPresent(Company.self, forKey: .company)
    }
  
}

struct Address : Codable {
    var street : String?
    var suite : String?
    var city : String?
    var zipcode : String?
    var geo : Geo?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.street, forKey: .street)
        try container.encodeIfPresent(self.suite, forKey: .suite)
        try container.encodeIfPresent(self.city, forKey: .city)
        try container.encodeIfPresent(self.zipcode, forKey: .zipcode)
    }
    enum CodingKeys: String, CodingKey {
        case street
        case suite
        case city
        case zipcode
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.street = try container.decodeIfPresent(String.self, forKey: .street)
        self.suite = try container.decodeIfPresent(String.self, forKey: .suite)
        self.city = try container.decodeIfPresent(String.self, forKey: .city)
        self.zipcode = try container.decodeIfPresent(String.self, forKey: .zipcode)
    }
}

struct Geo : Codable {
    var lat : String?
    var lng : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.lat, forKey: .lat)
        try container.encodeIfPresent(self.lng, forKey: .lng)
    }
    enum CodingKeys: String, CodingKey {
        case lat
        case lng
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.lat = try container.decodeIfPresent(String.self, forKey: .lat)
        self.lng = try container.decodeIfPresent(String.self, forKey: .lng)
    }
}
struct Company : Codable {
    var name : String?
    var catchPhrase : String?
    var bs : String?

}
