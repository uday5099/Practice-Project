//
//  UserCustomCell.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 15/01/23.
//

import UIKit

class UserCustomCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var bodyLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
