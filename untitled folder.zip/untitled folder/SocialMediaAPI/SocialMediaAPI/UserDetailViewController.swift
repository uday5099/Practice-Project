//
//  UserDetailViewController.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 15/01/23.
//

import UIKit

class UserDetailViewController: UIViewController, UITextViewDelegate {

    @IBOutlet weak var userDetailTableView: UITableView!

    var postDetails : [Post]?
    var dataToSend : Post?
    
    var postData : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
         AllPostData()
        
         userDetailTableView.dataSource = self
         userDetailTableView.delegate = self
    }
    
    func AllPostData(){
      var postInfo : [Post]?
     //   var userDetails : [User]?
        
        var urlStr = "https://jsonplaceholder.typicode.com/users"
        let detail = "/posts"
        //append query parameter on URL with ?
        let query = detail.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
          urlStr.append(query)

          let url = URL(string: urlStr)
          let request = URLRequest(url: url!)
        
          let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
              guard let data = data else {return}
              do {
                   self.postDetails = try JSONDecoder().decode([Post].self, from: data)
                  self.postDetails = postInfo
              }catch let err{
                  print(err)
              }
              DispatchQueue.main.async {
                  self.userDetailTableView.reloadData()
              }
          }
          dataTask.resume()
      }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UserDetailViewController : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postDetails?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userDetailTableView.dequeueReusableCell(withIdentifier: "UserCustomCell", for: indexPath) as! UserCustomCell

        let postData : Post = (postDetails![indexPath.row])
    
        cell.titleLabel?.text = postData.title
        cell.bodyLabel?.text = postData.body
     
    
        return cell
    }


}
