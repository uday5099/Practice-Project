//
//  CommentModel.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 15/01/23.
//

import Foundation

struct Comment : Codable {
    var postId : Int?
    var id : Int?
    var name : String?
    var email : String?
    var body : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.postId, forKey: .postId)
        try container.encodeIfPresent(self.id, forKey: .id)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.email, forKey: .email)
        try container.encodeIfPresent(self.body, forKey: .body)
    }
    enum CodingKeys: CodingKey {
        case postId
        case id
        case name
        case email
        case body
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.postId = try container.decodeIfPresent(Int.self, forKey: .postId)
        self.id = try container.decodeIfPresent(Int.self, forKey: .id)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.email = try container.decodeIfPresent(String.self, forKey: .email)
        self.body = try container.decodeIfPresent(String.self, forKey: .body)
    }
}
