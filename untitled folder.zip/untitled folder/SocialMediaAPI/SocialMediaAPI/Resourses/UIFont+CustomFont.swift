//
//  UIFont+CustomFont.swift
//  SocialMediaAPI
//
//  Created by Uday Patil on 16/01/23.
//

import Foundation
import UIKit

extension UIFont {
    static func groteskBold(with size: CGFloat) -> UIFont? {
        return UIFont(name: "HKGrotesk-Bold", size: size )
    }
    static func groteskMedium(with size: CGFloat) -> UIFont? {
        return UIFont(name: "HKGrotesk-Medium", size: size)
    }
    static func groteskExtraBold(with size: CGFloat) -> UIFont? {
        return UIFont(name: "HKGrotesk-ExtraBold", size: size)
    }
    static func groteskRegular(with size:CGFloat) -> UIFont? {
        return UIFont(name: "HKGrotesk-Regular", size: size)
    }
}
