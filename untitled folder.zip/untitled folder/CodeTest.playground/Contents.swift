import UIKit


//1. Examine whether the pairs and the orders of “{“,”}”,”(“,”)”,”[“,”]” are correct in exp.
//For example, the function should return 'true' for exp = “[()]{}{[()()]()}” and 'false' for exp = “[(])”.
                                                                                                    
func checkParentheses(s: String) -> Bool {
    
    let pairs: [Character: Character] = ["(": ")", "[": "]", "{": "}"]
    var stack: [Character] = []
    
    for char in s {
        
        if let match = pairs[char] {
            stack.append(match)
        }
        else if stack.last == char {
            stack.popLast()
        }
        else {
            return false
        }
    }
    return stack.isEmpty
}
checkParentheses(s: "{(])}")




//2. Given an Array find K, where K is smallest element in array and smaller than size of array, the task is to find the Kth smallest element in the given array. It is given that all array elements are distinct without sorting.
import UIKit

let arr: [Int] = [12, 3, 5, 7, 19]

var N = arr.count / arr[0]
var k = 2

func kSmallest(arr:[Int], N:Int, k:Int) -> Int {
    
    return arr[k-1]
    
}
