import UIKit

print("Hello Playground")

print("ios programming logic")

// print patterns
/*
for i in 1..<5{
    for j in 1...i {
        print("", terminator: "")
    }
    print("")
}

 //
 for i in 1..<5{
     for j in 1...i {
         print("*", terminator: "")
     }
     print("")
 }
 
//
for i in 0..<10 {
    print(String.init(repeating: "*", count: 10-i))
}
 
//row column and space triangle
for i in 1...10 {
    print(String.init(repeating: " ", count: 10-i)+String.init(repeating: "*", count: i))
}


//pyramid
for i in 1...10 {
    print(String.init(repeating: " ", count: 10-i)+String.init(repeating: "*", count: 2*i-1))
}
  

for i in 1...4
{
    for j in stride(from: 4, to: i, by: -1)
    {
        print(terminator: " ")
    }
    for k in 0...i
    {
      print(k, terminator: " ")
    }
    print(" ")
}
 */

for i in stride(from: 5, to: 0, by: -1){
    for j in 1...i {
        print(j,terminator: "")
    }
    print(" ")
}
