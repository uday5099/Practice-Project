//
//  ViewController.swift
//  UniversityApiQueryApp
//
//  Created by Bharat Silavat on 10/01/23.
//

import UIKit

class ViewController: UIViewController {
    
    var allDetail: USIDsDetail?
//    var allPupulationInfo: USIDsDetail?
    let stringUrl = "https://datausa.io/api/data?drilldowns=Nation&measures=Population"
    var sendingQuery: String = "drilldowns=Nation&measures=Population"
    @IBOutlet weak var populationTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .cyan
        populationTableView.dataSource = self
        populationTableView.delegate = self
        getData()
    }
    
    
    func getData(){
        var allPupulationInfo: USIDsDetail?
//        print("Get Data is Working ")
        let url = URL(string: stringUrl)
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { (data, responce, error) in
            
            if error == nil {
                let receivedData = data
//                print(receivedData ?? "Received Our Data")
            }else {
                print("Error :\(error?.localizedDescription ?? "There is Error Found")")
            }
            do{
                allPupulationInfo = try JSONDecoder().self.decode(USIDsDetail?.self, from: data!)
                print(allPupulationInfo ?? "")
                self.allDetail = allPupulationInfo
                DispatchQueue.main.async {
                    self.populationTableView.reloadData()
//                    print("Data is receiving")
                }
            }catch{
                print("Error : -\(error)")
            }
        }
        task.resume()
    }
}
    

extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return allDetail?.sourceArray?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCell", for: indexPath)
        cell.textLabel?.text = "\(allDetail?.dataArray?[indexPath.row].iDYear ?? 0)"
        cell.detailTextLabel?.text = "\(allDetail?.dataArray?[indexPath.row].population ?? 0)"
        return cell
        
    }
  
}

extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        populationTableView.deselectRow(at: indexPath, animated: true)
        
        performSegue(withIdentifier: "SecondVC", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "SecondVC"){
            
            let vc = segue.destination as! SecondViewController
            vc.receivingQuery = sendingQuery
            
        }
        
    }
    
    
}
