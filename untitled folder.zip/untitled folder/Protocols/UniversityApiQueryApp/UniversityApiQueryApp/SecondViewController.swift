//
//  SecondViewController.swift
//  UniversityApiQueryApp
//
//  Created by Bharat Silavat on 10/01/23.
//

import UIKit

class SecondViewController: UIViewController {
    
    var populationDetail: USIDsDetail?
    var detail: USIDsDetail?
    var receivingQuery : String?
    var sendingData : [Source] = []
    @IBOutlet weak var secondVCTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .green
        secondVCTableView.delegate = self
        secondVCTableView.dataSource = self
//        print(receivingQuery ?? "")
        getData()
    }
    
    func getData(){
//        print("Get Data is Working ")
        let url = URL(string: "https://datausa.io/api/data?\(receivingQuery!)")
        let request = URLRequest(url: url!)
        let session = URLSession.shared
        
        let task = session.dataTask(with: request) { (data, responce, error) in
            
            if error == nil {
                let receivedData = data
//                print(receivedData ?? "Received Our Data")
            }else {
                print("Error :\(error?.localizedDescription ?? "There is Error Found")")
            }
            do{
                self.populationDetail = try JSONDecoder().self.decode(USIDsDetail?.self, from: data!)
                print(self.populationDetail ?? "")
                self.detail = self.populationDetail
                DispatchQueue.main.async {
                    self.secondVCTableView.reloadData()
//                    print("Data is receiving")
                }
            }catch{
                print("Error : -\(error)")
            }
        }
        task.resume()
    }
}

extension SecondViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      
        
        return detail?.dataArray?.count ?? 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "SecondVC", for: indexPath)
        cell.textLabel?.text = detail?.dataArray?[indexPath.row].nation
        cell.detailTextLabel?.text = detail?.dataArray?[indexPath.row].year
        guard let sourceData : [Source] = detail?.sourceArray else { return cell}
        sendingData = sourceData
        return cell
    }
}

extension SecondViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        secondVCTableView.deselectRow(at: indexPath, animated: true)
        
        performSegue(withIdentifier: "ThirdVCS", sender: self)
    
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if (segue.identifier == "ThirdVCS"){
            
           let vc =  segue.destination as! ThirdViewController
            vc.receivingData = sendingData
        }
    }
    
    
}
