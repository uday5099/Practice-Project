//
//  BitcoinTableViewCell.swift
//  NetworkProject
//
//  Created by Uday Patil on 04/01/23.
//

import UIKit

class BitcoinTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var lastUpdatedLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var rankLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    

    func configure(dateStr: String) {
            let formatter = DateFormatter()
           // print(dateStr)
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
            formatter.timeZone = TimeZone.gmt

            guard let date = formatter.date(from: dateStr) else {
                lastUpdatedLabel.text = "Date not converted"
                return
            }
           // print(date)
            formatter.timeZone = TimeZone(identifier: "PST")
            formatter.dateFormat = "D MMM YYYY, hh:mm:ss a"
            let str = formatter.string(from: date)
            lastUpdatedLabel.text = str
        }
 
}
