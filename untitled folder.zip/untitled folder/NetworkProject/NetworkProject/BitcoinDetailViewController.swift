//
//  BitcoinDetailViewController.swift
//  NetworkProject
//
//  Created by Uday Patil on 05/01/23.
//

import UIKit

class BitcoinDetailViewController: UIViewController {

    @IBOutlet weak var bitcoinDetailTable: UITableView!
    
    var responseData : [Currency]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

extension BitcoinDetailViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return responseData?[section].quotes.values.count ?? 0
    }
   
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BitcoinDetailCell", for: indexPath)
//
//        guard let detailedData = responseData?[indexPath.row].quotes else { return cell }
//
//        let value = responseData?[indexPath.row].quotes
//        let xyz = value?.keys
//
//        let keys = [String](detailedData.keys)
//        let key = keys[indexPath.section]
//
//        guard let valuesForKey: Quote = detailedData[key] else { return cell }
//
//        cell.textLabel?.text = "\(valuesForKey.athDate ?? "")"
//
     return cell
    }

}
