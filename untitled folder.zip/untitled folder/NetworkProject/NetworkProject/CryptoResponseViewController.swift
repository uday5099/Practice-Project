//
//  CryptoResponseViewController.swift
//  NetworkProject
//
//  Created by Uday Patil on 06/01/23.
//

import UIKit

class CryptoResponseViewController: UIViewController {

    @IBOutlet weak var cellView: UIView!
    @IBOutlet weak var symbolView: UIView!
    @IBOutlet weak var symbolLabel: UILabel!
    
    @IBOutlet weak var fifteenLabel: UILabel!
    @IBOutlet weak var thirtyLabel: UILabel!
    @IBOutlet weak var hourLabel: UILabel!
    
    @IBOutlet weak var sixHourLabel: UILabel!
    @IBOutlet weak var twelveHourLabel: UILabel!
    @IBOutlet weak var twentyfourLabel: UILabel!
    
    @IBOutlet weak var sevenDayLabel: UILabel!
    @IBOutlet weak var thirtydayLabel: UILabel!
    @IBOutlet weak var oneYearLabel: UILabel!
    
    @IBOutlet weak var maxSupplyLabel: UILabel!
    @IBOutlet weak var totalSupplyLabel: UILabel!
    @IBOutlet weak var marketCapLabel: UILabel!
    @IBOutlet weak var betaValueLabel: UILabel!
    
    var dataToSend : Quote?      // allQuote struct data from bitcoin VC
    var allDataToSend : Currency?  // all data received
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //   show value in detail View Controller
        
        fifteenLabel.text = "\(dataToSend?.percentChange15m ?? 0)"
        thirtyLabel.text = "\(dataToSend?.percentChange30m ?? 0)"
        hourLabel.text = "\(dataToSend?.percentChange1h ?? 0)"
        sixHourLabel.text = "\(dataToSend?.percentChange6h ?? 0)"
        twelveHourLabel.text = "\(dataToSend?.percentChange12h ?? 0)"
        twentyfourLabel.text = "\(dataToSend?.percentChange24h ?? 0)"
        sevenDayLabel.text = "\(dataToSend?.percentChange7d ?? 0)"
        thirtydayLabel.text = "\(dataToSend?.percentChange30d ?? 0)"
        oneYearLabel.text = "\(dataToSend?.percentChange1y ?? 0)"
        symbolLabel.text = allDataToSend?.symbol
        maxSupplyLabel.text = "\(allDataToSend?.maxSupply ?? 0)"
        totalSupplyLabel.text = "\(allDataToSend?.totalSupply ?? 0)"
        betaValueLabel.text = "\(allDataToSend?.betaValue ?? 0)"
        marketCapLabel.text = "\(dataToSend?.marketCap ?? 0)"
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let gradientLayer = CAGradientLayer()
            gradientLayer.frame = symbolView.frame

        let fromColor  = UIColor.systemPink.cgColor
        let midddleColor  = UIColor.white.cgColor
        let lastColor  = UIColor.purple.cgColor

        gradientLayer.colors = [fromColor, midddleColor, lastColor]
        symbolView.layer.addSublayer(gradientLayer)
        symbolView.addSubview(symbolLabel)

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}
