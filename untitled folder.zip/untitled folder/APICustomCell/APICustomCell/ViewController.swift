//
//  ViewController.swift
//  APICustomCell
//
//  Created by Uday Patil on 12/01/23.
//

import UIKit

class ViewController: UIViewController, ConnectionManagerDelegate {
    var api: API?
    
    func finishTaskWithResponse(data: Data?, error: Error?) {
        DispatchQueue.main.async{
           // self.removeLoading()
        }
        if error == nil {
            guard let data = data else { return }
            let decoder = JSONDecoder()
            do{
                self.authorData = try? decoder.decode(PoemAuthor?.self, from: data)
            } catch let err {
                print(err)
            }
            DispatchQueue.main.async {
                self.authorNameTableView.reloadData()
            }
        }
    }
    
    var authorData : PoemAuthor?
    let manager = ConnectionManager()
    @IBOutlet weak var authorNameTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        api = .authorName
        authorNameTableView.dataSource = self
        authorNameTableView.delegate = self
        
        manager.delegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
        manager.sessionStart()
    }
}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authorData?.authors?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = authorNameTableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        
        let author = authorData?.authors?[indexPath.row]
        cell.textLabel?.text = author

        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let singleAuthor = authorData?.authors?[indexPath.row]
        
        performSegue(withIdentifier: "Author", sender: singleAuthor)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Author" {
            let pushToNextVC = segue.destination as! CustomViewController
            pushToNextVC.name = (sender as! String)
        }
    }
    
}
