//
//  CustomViewController.swift
//  APICustomCell
//
//  Created by Uday Patil on 13/01/23.
//

import UIKit

class CustomViewController: UIViewController {

    @IBOutlet weak var customCellView: UIView!
    @IBOutlet weak var authorNameLabel: UILabel!
    @IBOutlet weak var customTableView: UITableView!
    
    var name : String?
    var authorArray : [Poem]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        customTableView.dataSource = self
        customTableView.delegate = self
        
        AuthorsData()
    }
    
    func AuthorsData(){
        
          var urlStr = "https://poetrydb.org/author/"
        //append query parameter on URL with ?
          let query = name?.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
          urlStr.append(query)

          let url = URL(string: urlStr)
          let request = URLRequest(url: url!)
        
          let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
              guard let data = data else {return}
              do {
                  self.authorArray = try JSONDecoder().decode([Poem].self, from: data)
              }catch let err{
                  print(err)
              }
              DispatchQueue.main.async {
                  self.customTableView.reloadData()
              }
          }
          dataTask.resume()
      }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension CustomViewController : UITableViewDataSource , UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authorArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = customTableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomTableViewCell
        
       // let cellData = authorArray?[indexPath.row]
       //     let name = cellData?.author
       //   let poemtitle = cellData?.title
        
        let detail : Poem = authorArray![indexPath.row]

        cell.authorNameLabel.text = "Name: \(detail.author ?? "")"
        cell.poemNameLabel?.text = detail.title
        
        return cell
    }
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        100
//    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let poemArray: Poem = authorArray![indexPath.row]
        let poem : [String] = poemArray.lines ?? [""]
        
        performSegue(withIdentifier: "Poem", sender: poem)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "Poem" {
            
            let PoemVC = segue.destination as! PoemViewController
            let poem = sender as! [String]
            PoemVC.allPoem = poem.joined(separator: ",")
        }
    }
}
