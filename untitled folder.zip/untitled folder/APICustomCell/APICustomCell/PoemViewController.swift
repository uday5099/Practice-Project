//
//  PoemViewController.swift
//  APICustomCell
//
//  Created by Uday Patil on 13/01/23.
//

import UIKit

class PoemViewController: UIViewController, UITextViewDelegate {

    @IBOutlet weak var allPoemView: UITextView!
    
    var allPoem : String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        allPoemView.delegate = self
        allPoemView.text = allPoem?.description
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
