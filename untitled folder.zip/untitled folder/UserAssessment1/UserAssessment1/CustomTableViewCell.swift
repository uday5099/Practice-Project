//
//  CustomTableViewCell.swift
//  UserAssessment1
//
//  Created by Uday Patil on 20/01/23.
//

import UIKit

class CustomTableViewCell: UITableViewCell {


    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var titleTextView: UITextView!
    @IBOutlet weak var bodyTextView: UITextView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
