//
//  ViewController.swift
//  UserAssessment1
//
//  Created by Uday Patil on 20/01/23.
//

import UIKit

class ViewController: UIViewController {

    var allUsers : [User]?
    let section : [String] = ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"]
    var sortedArr : [String] = []
    
    @IBOutlet weak var userListTableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        userListTableView.dataSource = self
        userListTableView.delegate = self
        hitUrl()
    }
    
    func hitUrl(){
        let baseUrl = "https://jsonplaceholder.typicode.com/users"
        
        guard let url = URL(string: baseUrl) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
            
            if error == nil {
                guard let data = data else {return}
                do{
                    self.allUsers = try JSONDecoder().decode([User].self, from: data)
                    
                    // for sorting name alphabetically
                    for item in self.allUsers!{
                        let nameId = item.name as String?
                        //print(nameid)
                        self.sortedArr.append(nameId ?? "")
                        self.sortedArr.sort()
                    }
                    //print(self.sortedArr)
                }catch let error{
                    print(error)
                }
                DispatchQueue.main.async {
                    self.userListTableView.reloadData()
                }
            }
        }
        dataTask.resume()
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return self.section[section]
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sortedArr.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = userListTableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath)
        let userName = sortedArr[indexPath.row]
        
        // for removing last name from full name string
        let fullNameArr = userName.components(separatedBy: " ")
        cell.textLabel?.text = fullNameArr[0]
        
        // for odd even cell color
        cell.backgroundColor = indexPath.row % 2 == 0 ? .blue : .green
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let DetailsArray = allUsers![indexPath.row]
        
        self.performSegue(withIdentifier: "UserDetail", sender: DetailsArray)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "UserDetail" {
            let targetVc = segue.destination as! AddressViewController
            let user = sender as! User?
            targetVc.userList = user
        }
    
    }
}
