//
//  PostViewController.swift
//  UserAssessment1
//
//  Created by Uday Patil on 20/01/23.
//

import UIKit

class PostViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var UserId : Int?
    var userPost : [Post]?
    
    @IBOutlet weak var postTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        postTableView.dataSource = self
        postTableView.delegate = self
        HitUrl()
    }
    
    func HitUrl(){
        let baseUrl = "https://jsonplaceholder.typicode.com/users/\(UserId!)/posts"

        guard let url = URL(string: baseUrl) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
           
            if error == nil {
                guard let data = data else {return}
                do{
                    self.userPost = try JSONDecoder().decode([Post].self, from: data)
                }catch let er{
                    print(er)
                }
                DispatchQueue.main.async {
                    self.postTableView.reloadData()
                }
            }
        }
        dataTask.resume()
    }

    /*
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userPost?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = postTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomTableViewCell
        
        let postArray : Post = userPost![indexPath.row]
        print(postArray)
        cell.idLabel?.text = "UserId:\(postArray.userId ?? 0)"
        cell.titleTextView?.text = "Title:\(postArray.title ?? "")"
        cell.bodyTextView?.text = "Body:\(postArray.body ?? "")"
        return cell
    }
    
}

