//
//  AddressViewController.swift
//  UserAssessment1
//
//  Created by Uday Patil on 20/01/23.
//

import UIKit

class AddressViewController: UIViewController {

    var userList : User?

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var addressTextView: UITextView!
    @IBOutlet weak var phoneNoLabel: UILabel!
    @IBOutlet weak var websiteLabel: UILabel!
    @IBOutlet weak var companyNameTextView: UITextView!
    
    @IBOutlet weak var viewPost: UIButton!
    
    override func viewDidLoad() {
            super.viewDidLoad()
        nameLabel.text = userList?.name
        
        addressTextView.text = "Street : \(userList?.address?.street ?? "") , Suite :  \(userList?.address?.suite ?? "") , City : \(userList?.address?.city ?? "") , ZipCode :  \(userList?.address?.zipcode ?? "") ,  Lattitude : \(userList?.address?.geo?.lat ?? "") , Longitude : \(userList?.address?.geo?.lng ?? "")"
        
        phoneNoLabel.text = " \(userList?.phone ?? "")"
        
        websiteLabel.text = " \(userList?.website ?? "")"
        
        companyNameTextView.text = " Name : \(userList?.company?.name ?? "").\n BS : \(userList?.company?.bs ?? "").\n CatchPhrase : \(userList?.company?.catchPhrase ?? "")."
        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    @IBAction func viewPostButton(_ sender: Any) {
        let userId = userList?.id
       
        let PostViewController = self.storyboard?.instantiateViewController(withIdentifier: "PostViewController") as! PostViewController
            PostViewController.UserId = userId
            self.navigationController?.pushViewController(PostViewController, animated: true)
    }
}
