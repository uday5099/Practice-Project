//
//  PoemModel.swift
//  PoemDataUrl
//
//  Created by Uday Patil on 11/01/23.
//

import Foundation

struct Poem : Codable {
    var title : String?
    var author : String?
    var lines : [String]?
    var linescount : String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.title, forKey: .title)
        try container.encodeIfPresent(self.author, forKey: .author)
        try container.encodeIfPresent(self.lines, forKey: .lines)
        try container.encodeIfPresent(self.linescount, forKey: .linescount)
    }
    enum CodingKeys: String, CodingKey {
        case title
        case author
        case lines
        case linescount
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.title = try container.decodeIfPresent(String.self, forKey: .title)
        self.author = try container.decodeIfPresent(String.self, forKey: .author)
        self.lines = try container.decodeIfPresent([String].self, forKey: .lines)
        self.linescount = try container.decodeIfPresent(String.self, forKey: .linescount)
    }
}
