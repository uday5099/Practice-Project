//
//  ViewController.swift
//  PoemDataUrl
//
//  Created by Uday Patil on 11/01/23.
//

import UIKit

class ViewController: UIViewController, ConnectionManagerDelegate {
    var api: API?
    
    func finishTaskWithResponse(data: Data?, error: Error?) {
        if error == nil {
            guard let data = data else { return }
            let decoder = JSONDecoder()
            do{
                self.authorData = try? decoder.decode(PoemAuthor?.self, from: data)
            } catch let err {
                print(err)
            }
            DispatchQueue.main.async {
                self.authorTableView.reloadData()
            }
        }
    }
    
    var authorData : PoemAuthor?
    let manager = ConnectionManager()
    
    @IBOutlet weak var authorTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        api = .authorName  //Enum case 
        
        authorTableView.dataSource = self
        authorTableView.delegate = self
        view.backgroundColor = .brown
        manager.delegate = self
    }

    override func viewDidAppear(_ animated: Bool) {
        manager.sessionStart()
    }
}
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return authorData?.authors?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AuthorCell", for: indexPath)
      
        let author = authorData?.authors?[indexPath.row]
        
        cell.textLabel?.text = author
        cell.backgroundColor = .white
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let singleAuthor = authorData?.authors?[indexPath.row]
        performSegue(withIdentifier: "AuthorResponse", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "AuthorResponse" {
            let target = segue.destination as! AuthorsViewController
            target.name = (sender as? String) ?? ""
        }
    }
}
