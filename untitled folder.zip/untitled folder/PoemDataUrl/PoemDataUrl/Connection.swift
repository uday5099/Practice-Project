//
//  Connection.swift
//  PoemDataUrl
//
//  Created by Uday Patil on 11/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    var api : API? { get set }
    
    func finishTaskWithResponse(data:Data?, error:Error?)
}

 enum API : String {
    case authorName = "https://poetrydb.org/author"
}

class ConnectionManager {
    var delegate : ConnectionManagerDelegate?
    
    func sessionStart(){
        guard let delegate = self.delegate,
              let api = delegate.api else {return}
        let url = api.rawValue
        self.taskStart(url)
    }
    
    func taskStart(_ url :String){
        
        guard let url = URL(string: url) else {return}
        let request = URLRequest(url: url)
        let dataTask = URLSession.shared.dataTask(with: request) { data, response, error in
           
            guard let delegate = self.delegate else {return}
            delegate.finishTaskWithResponse(data: data, error: error)
        }
        dataTask.resume()
    }
    
}
