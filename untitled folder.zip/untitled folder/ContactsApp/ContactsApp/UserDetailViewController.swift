//
//  UserDetailViewController.swift
//  ContactsApp
//
//  Created by Bharat Silavat on 20/01/23.
//

import UIKit

class UserDetailViewController: UIViewController {
    
    @IBOutlet weak var phoneNumber : UILabel!
    @IBOutlet weak var website: UILabel!
    @IBOutlet weak var comanyName: UILabel!
    @IBOutlet weak var  address: UILabel!
    
    var givenId: Int = 0
    var selectedDataRec: UserInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        phoneNumber.text = selectedDataRec?.phone
        website.text = selectedDataRec?.website
        comanyName.text = "\(selectedDataRec?.company?.name ?? "") \(selectedDataRec?.company?.bs ?? "")"
        address.text = "\(selectedDataRec?.address?.suite ?? "") \(selectedDataRec?.address?.street ?? "") \(selectedDataRec?.address?.city ?? "") \(selectedDataRec?.address?.zipcode ?? "")"
        self.title = selectedDataRec?.name ?? ""
        givenId = selectedDataRec?.id ?? 0
        
    }
    
    @IBAction func postBtnAction(_ sender: UIButton) {
        performSegue(withIdentifier: "PostId", sender: sender)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "PostId" {
            let vc = segue.destination as! PostViewController
            vc.commonId = givenId
            
        }
    }
    
    
}
