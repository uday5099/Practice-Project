//
//  Network.swift
//  ContactsApp
//
//  Created by Bharat Silavat on 20/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    
    var api : APIs? {get set}
    
    func didCompleteTask(with data:Data?, error:Error?)
    
    
    
}

class ConnectionManager{
    
    var delegate : ConnectionManagerDelegate?
    
    private let session = URLSession.shared
    var url: String?
    
    init(delegate: ConnectionManagerDelegate? = nil, url: String? = nil) {
        self.delegate = delegate
        self.url = url
    }
    
    //MARK: - making function to Start a Session -
    
    func startSession(){
        
        guard let delegate = delegate,
              let api = delegate.api else { return }
        let url = api.rawValue
        self.hitUrl(url)
        
    }
    
    // MARK: - Private Function To hitUrl AfterStarting UrlSession -
    
    private func hitUrl(_ provideStringUrlHere : String, queryParam: [String: String]? = nil) {
        
        guard let url = URL(string: provideStringUrlHere) else { return }
        let request = URLRequest(url: url)
        
        let task = URLSession.shared.dataTask(with: request) { (data, responce, error ) in
            
            guard let delegate = self.delegate else {return}
            delegate.didCompleteTask(with: data, error: error)
            
        }.resume()
        
    }
    
}

// MARK: - Create and Enum to pass all API's Url's -

enum APIs: String {
    
    case contactsApiUrl = "https://jsonplaceholder.typicode.com/users"
    case postsApiUrl =  "https://jsonplaceholder.typicode.com/posts"
    
}
