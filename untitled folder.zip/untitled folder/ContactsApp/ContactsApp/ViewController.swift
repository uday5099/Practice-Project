//
//  ViewController.swift
//  ContactsApp
//
//  Created by Bharat Silavat on 20/01/23.
//

import UIKit

class ViewController: UIViewController,ConnectionManagerDelegate {
    
    private let indexLetters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
    var sectionTitle = [String]()
    // create Blank Dictionary -
    var contactDict = [String: [String]]()
    
    var api: APIs?
    var usersArray: [UserInfo]?
    let manager = ConnectionManager()
    var sendingTittle: String = ""
    var contactNamesDictionary = [String: [String]]()
    
    var selectedData : UserInfo?
    
    @IBOutlet weak var contactTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        contactTableView.delegate = self
        contactTableView.dataSource = self
        api = APIs.contactsApiUrl
        manager.delegate = self
        manager.startSession()
        
    }
    
    func didCompleteTask(with data: Data?, error: Error?) {
        guard error == nil else {return}
        guard let data = data else {return}
        do {
            usersArray = try JSONDecoder().self.decode([UserInfo]?.self, from: data)
        }catch{
            print("Error : \(error)")
        }
        DispatchQueue.main.async {
            self.contactTableView.reloadData()
        }
    }
    
}

extension ViewController: UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return indexLetters.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return indexLetters[section].description
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return usersArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ContactsCell", for: indexPath)
//        cell.textLabel?.textColor = .random()
        
        if indexPath.row%2 == 0{
            cell.backgroundColor = .systemPink
            cell.textLabel?.textColor = .white
            
        }else {
            cell.backgroundColor = .gray
        }
        
        let fullName  = usersArray?[indexPath.row].name
        let names = usersArray?.compactMap { $0.name }
//        print(names)
        sectionTitle = Array(Set(names?.compactMap({String($0.prefix(1))}) ?? []))
        sectionTitle.sort()
//        print(sectionTitle)
        
        var components = fullName?.components(separatedBy: " ")
        if components!.count > 0 {
            let firstName = components?.removeFirst()
            cell.textLabel?.text = firstName
            return cell
        }
        return cell
    }
    
    // Rotating table View By CA LAyer and Transform
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.layer.transform = CATransform3DMakeScale(0.1, 0.1, 1.0)
        UIView.animate(withDuration: 1.0) {
            cell.layer.transform = CATransform3DMakeScale(1.0, 1.0, 1.0)
        }
    }
    // Setting Swipe Delete Action to cell // handler will be nil for now
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .normal, title: "Delete", handler: {_,_,_ in "NA"})
        return .none
    }
 
    // to swipe or change row index by Can move row at and to move rowAt -
    
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        let selectedItem = usersArray?[sourceIndexPath.row]
        usersArray?.remove(at: sourceIndexPath.row)
        usersArray?.insert(selectedItem!, at: destinationIndexPath.row)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        contactTableView.beginUpdates()
        usersArray?.remove(at: indexPath.row)
        contactTableView.deleteRows(at: [indexPath], with: .fade)
        contactTableView.endUpdates()
    }
}
extension ViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.contactTableView.deselectRow(at: indexPath, animated: true)
        
        selectedData = usersArray?[indexPath.row]
        performSegue(withIdentifier: "SecondVC", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SecondVC" {
            
            let vc = segue.destination as! UserDetailViewController
            vc.selectedDataRec = selectedData
        }
    }
    
}
extension CGFloat {
    static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
}

extension UIColor {
    static func random() -> UIColor {
        return UIColor(red:   .random(),
                       green: .random(),
                       blue:  .random(),
                       alpha: 1.0)
    }
}
