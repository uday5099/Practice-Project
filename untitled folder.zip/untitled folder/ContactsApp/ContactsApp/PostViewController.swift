//
//  PostViewController.swift
//  ContactsApp
//
//  Created by Bharat Silavat on 20/01/23.
//

import UIKit

class PostViewController: UIViewController,ConnectionManagerDelegate {
    
    var api: APIs?
    var manager = ConnectionManager()
    var postArray: [PostList]?
    var commonId: Int?
    
    @IBOutlet weak var postTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        postTableView.dataSource = self
        manager.delegate = self
        api = APIs.postsApiUrl
        manager.startSession()
        
    }
    
    func didCompleteTask(with data: Data?, error: Error?) {
        guard error == nil else {return}
        guard let data = data else {return}
        
        do {
            postArray = try JSONDecoder().self.decode([PostList]?.self, from: data)
        }catch{
            print("Error : \(error)")
        }
        DispatchQueue.main.async {
            self.postTableView.reloadData()
        }
    }
    
}

extension PostViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postArray?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as! PostTableViewCell
        
        if (postArray?[indexPath.row].id == commonId){
            cell.userId.text = "UserId : \(postArray?[indexPath.row].userId ?? 0)"
            cell.title.text = "Title : \(postArray?[indexPath.row].title ?? "")"
            cell.body.text = postArray?[indexPath.row].body
            return cell
        }
        return cell
    }
    
}

