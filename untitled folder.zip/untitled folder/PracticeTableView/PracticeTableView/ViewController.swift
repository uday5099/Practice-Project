//
//  ViewController.swift
//  PracticeTableView
//
//  Created by Uday Patil on 13/12/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var myTable:UITableView!
    
    //keys are string and values are array of string
    var strDict: [String: [String]] = ["Vowel": ["A", "E", "I", "O", "U"], "Consonants": ["B","C","D","F","G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X"], "Numbers": ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    func numberOfSections(in tableView: UITableView) -> Int {
        return strDict.keys.count
    }
   
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     
        let Keys = Array(strDict.keys)
        let key = Keys[section]
        //print(key)
        
        return strDict[key]?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"mytableViewCell")
        
        let keyArrey = Array(strDict.keys)
        //print(keyArrey)
        let varA = keyArrey[indexPath.section]
        //print(varA)
        cell?.textLabel?.text = strDict[varA]?[indexPath.row]

        return cell!
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let keyArray = Array(strDict.keys)
        let key = keyArray[section]
        
        return key
      }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
            return "Section No: \(section)"
       }
    

}

