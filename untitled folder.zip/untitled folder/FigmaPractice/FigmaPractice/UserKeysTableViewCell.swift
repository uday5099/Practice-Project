//
//  UserKeysTableViewCell.swift
//  FigmaPractice
//
//  Created by Uday Patil on 31/01/23.
//

import UIKit
import Foundation

protocol SignUpCellDelegate {
    
    func inputView(for key : User.Key) -> UIView
    func textfieldStartEditing(for key: User.Key)
    
}
class UserKeysTableViewCell: UITableViewCell, UITextFieldDelegate {
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        guard let delegate = delegate,
              let userkey = userKey else { return false }
        delegate.textfieldStartEditing(for: userkey) // global var for user
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        switch self.userKey {
        case .name:
           // self.user?.name = nameTF.text
            if ((nameTF.text?.isValidName(name: "uday509")) == true) {
                nameTF.textColor = .blue
            } else {
                nameTF.textColor = .red
            }
        case .email:
            if (nameTF.text?.checkValidEmail() == true) {
                nameTF.textColor = .black
                let emailTF = self.user?.email
            } else {
                nameTF.textColor = .red
            }
        default:
            print("")
        }
    }
    
    var delegate : SignUpCellDelegate?
    var user: User? //struct
    var userKey : User.Key? // enum
    // var trimmingCharacters : UITextChecker?
    
    @IBOutlet weak var nameTF: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func setuToolBar() -> UIToolbar {
        let frame = UIScreen.main.bounds
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: frame.size.width, height: 45))
        //        self.accesoryLabel = UILabel(frame: CGRect(x: 0, y: 0, width: frame.size.width/2, height: 30))
        //        self.accesoryLabel?.adjustsFontSizeToFitWidth = true
        //        self.accesoryLabel?.minimumScaleFactor = 0.5
        let doneBarButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(doneButton))
        let space = UIBarButtonItem(systemItem: .flexibleSpace)
        //        let label = UIBarButtonItem(customView: self.accesoryLabel!)
        let cancelBarButton = UIBarButtonItem(title: "cancel", style: .plain, target: self, action: #selector(endEDiting))
        toolbar.items = [cancelBarButton, doneBarButton]
        return toolbar
    }
    
    @objc func doneButton() {
        //  self.countryTextField.text = self.accesoryLabel?.text
        self.nameTF.endEditing(true)
    }
    
    @objc func endEDiting() {
        // self.accesoryLabel?.text = self.countryTextField.text
        self.nameTF.endEditing(true)
    }
    
    func updateUI(with Key : User.Key, for user: User) {
        
        nameTF.delegate = self
        self.user = user  //which is struct or model
        self.userKey = Key  // which is enum
        nameTF.placeholder = Key.rawValue
        
        switch Key {
        case .name:
            self.nameTF.text = user.name
            self.nameTF.keyboardType = .default
           // self.nameTF.inputAccessoryView = self.setuToolBar()
            
            
        case .email:
            self.nameTF.text = user.email
            self.nameTF.keyboardType = .emailAddress
            //   self.nameTF.text = self.isValidEmail()
            
        case .sex:
            self.nameTF.text = user.gender?.rawValue ?? ""
            guard let delegate = delegate else { return }
            self.nameTF.inputView = delegate.inputView(for: Key)
            
        case .dob:
            self.nameTF.text = self.formattedDate()
            guard let delegate = delegate else { return }
            self.nameTF.inputView = delegate.inputView(for: Key)
            
        case .country:
            self.nameTF.text = user.country?.name
            guard let delegate = delegate else { return }
            self.nameTF.inputView = delegate.inputView(for: Key)
            
        case .password:
            self.nameTF.text = user.password
            //` self.nameTF.isSecureTextEntry = true
            self.nameTF.keyboardType = .default
            //  self.nameTF.delegate = self.isValidPassword() as? any UITextFieldDelegate
            
            
        case .phone:
            self.nameTF.text = "\(user.phone ?? 0)"
            self.nameTF.keyboardType = .phonePad
        }
        
    }
    func formattedDate() -> String {
        guard let dob = user?.dob else { return "" }
        
        let date = Date(timeIntervalSince1970: dob) ?? Date()
        let formatter = DateFormatter()
        
        // formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        formatter.dateFormat = "hh:mm:ss a 'on' MMMM dd, yyyy"
        // formatter.dateFormat = "E, d MMM yyyy HH:mm:ss Z"
        // formatter.dateFormat = "MMM d, yyyy"
        //  formatter.dateFormat = "MM/dd/yyyy"
        let dateStr = formatter.string(from: date)
        
        return dateStr
    }
}
    extension String {
        func checkValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive);
        return (regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil)
            
        }
        func isValidName(name: String) -> Bool {
            //Declaring the rule of characters to be used. Applying rule to current state. Verifying the result.
            let regex = "[A-Za-z]{2,}"
            let test = NSPredicate(format: "SELF MATCHES %@", regex)
            let result = test.evaluate(with: name)
            return result
        }
        
    }

