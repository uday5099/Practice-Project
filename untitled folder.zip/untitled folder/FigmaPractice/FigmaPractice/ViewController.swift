//
//  ViewController.swift
//  FigmaPractice
//
//  Created by Uday Patil on 17/01/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }


}

