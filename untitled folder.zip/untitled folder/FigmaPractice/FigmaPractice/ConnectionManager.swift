//
//  ConnectionManager.swift
//  FigmaPractice
//
//  Created by Uday Patil on 18/01/23.
//

import Foundation

protocol ConnectionManagerDelegate {
    func didFinishTask(data: Data?, error: Error?)
        
}
class ConnectionManager {
    var delegate : ConnectionManagerDelegate?
    
    private let session = URLSession.shared
    var url : String?
    
    init(delegate: ConnectionManagerDelegate? = nil, url: String? = nil) {
        self.delegate = delegate
        self.url = url
    }
    
    //give URL and call performTask Function
    
    func login (with loginDict:[String:String]) {
        let url = "http://testurapp.com/iostesting/login.php"
        performTask(url, params: loginDict)
    }
    
    private func performTask(_ provideStringUrlHere : String, params: [String: String]? = nil) {
           guard let url = URL(string: provideStringUrlHere) else { return }
           var request = URLRequest(url: url)

           if let params = params {
               do {
                   let encoder = JSONEncoder()
                   request.httpBody = try encoder.encode(params)
                   request.httpMethod = "POST"
               } catch let error {
                   print(error)
               }
           }
           let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
               guard let delegate = self.delegate else { return }
               delegate.didFinishTask(data: data, error: error)
           }
           task.resume()
       }
   }

