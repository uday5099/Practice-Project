//
//  LoginViewController.swift
//  FigmaPractice
//
//  Created by Uday Patil on 17/01/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    var email: String = ""
    var password:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loginButton.isEnabled = false
        
    }
    
    @IBAction func loginButtonClicked(){
        let manager = ConnectionManager(delegate: self)
        manager.login(with: ["user": self.email, "pass": self.password])
        
    }

}
extension LoginViewController: ConnectionManagerDelegate {
    
    func didFinishTask(data: Data?, error: Error?) {
        guard error == nil else {return}
        guard let data = data else {return}
        let str = String(data: data, encoding: .utf8) ?? ""
              print("response \(str)")
 
      }
  }
extension LoginViewController: UITextFieldDelegate {
  //
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
  //
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        print("Range \(range), String: \(string)")
        return true
    }
  //
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
  //
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.emailTF {
            self.email = textField.text ?? ""
        }
        if textField == self.passwordTF {
            self.password = textField.text ?? ""
        }
        if self.email.isValidEmail() && self.password.count > 5 {
            self.loginButton.isEnabled = true
        }
    }
}
//
extension String {
    func isValidEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid

        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)

        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}
