//
//  SignUpViewController.swift
//  FigmaPractice
//
//  Created by Uday Patil on 31/01/23.
//

import UIKit

class SignUpViewController: UIViewController, SignUpCellDelegate {
    
    func textfieldStartEditing(for key: User.Key) {
        self.editingKey = key
    }
    
    func inputView(for key: User.Key) -> UIView {
        switch key {
        case .sex,.country :
            return self.picker
        case .dob :
            return self.signupDatePicker
        default:
            return UIView()
        }
    }

    @IBOutlet weak var picker : UIPickerView!
    @IBOutlet weak var userTableView: UITableView!
  
    @IBOutlet var signupHeaderView: UIView!
    @IBOutlet var signupDatePicker: UIDatePicker!
    
    var userKeyArray : [User.Key] = [.name,.email,.sex,.country,.dob,.password,.phone]
    var genderArray : [User.Gender] = [.male,.female,.unknown]
    var countryArray : [Country] = []

    var editingKey : User.Key?
    var user: User = User()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getCountry()
        userTableView.dataSource = self
        userTableView.estimatedRowHeight = 285
        userTableView.rowHeight = UITableView.automaticDimension
        userTableView.tableHeaderView = signupHeaderView
    }

    func getCountry() {
        guard let url = Bundle.main.url(forResource: "country", withExtension: "json") else { return }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            countryArray = try decoder.decode([Country].self, from: data)
            //print(countryArray)
        
            DispatchQueue.main.async { [weak self] in
                guard let self = self else { return }
                self.picker.reloadAllComponents()
            }
        }catch let error {
            print(error)
        }
    }
    
    @IBAction func selectDate(_ sender: Any) {
        let date = self.signupDatePicker.date
        user.dob = date.timeIntervalSince1970
        userTableView.reloadData()
    }
}

extension SignUpViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userKeyArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "signupCell", for: indexPath) as! UserKeysTableViewCell
        
        let key = userKeyArray[indexPath.row]
        cell.delegate = self
        cell.updateUI(with: key, for: user)

        
        return cell
    }
}
extension SignUpViewController : UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        switch editingKey {
        case .country :
            return countryArray.count
        case .sex :
            return genderArray.count
            
        default :
            return 0
        }
    }
}

extension SignUpViewController : UIPickerViewDelegate {
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        switch editingKey {
        case .sex :
            let type = genderArray[row]
            return type.rawValue
        case .country :
            let country = countryArray[row]
            return country.name
        default :
            return ""
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch editingKey {
        case .sex :
            let type = genderArray[row]
            self.user.gender = type
        case .country :
            let countryname = countryArray[row]
            self.user.country = countryname
            
        default :
            print("")
        }
        self.userTableView.reloadData()
    }
   
}
extension String {
    func validEmail() -> Bool {
        // here, `try!` will always succeed because the pattern is valid
        let regex = try! NSRegularExpression(pattern: "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$", options: .caseInsensitive)
        return regex.firstMatch(in: self, options: [], range: NSRange(location: 0, length: count)) != nil
    }
}

    class User {
        var name :String?
        var email : String?
        var gender : Gender?
        var country : Country?
        var dob : Double?
        var password : String?
        var phone : Int?
        
    
        enum Key : String {
            case name = "Enter Your Name"
            case email = "Enter Email"
            case sex = "Enter Sex"
            case country = "Select Country"
            case dob = "Select Date of Birth"
          //  case username = "Enter Username"
            case password = "Enter Password"
            case phone = "Enter Your Number"
            
        }
        enum Gender : String {
            case male = "Male"
            case female = "Female"
            case unknown = "Dont Want to Reaveal"
        }
}
struct Country : Codable {
    var name : String?
    var code : String?
    
    init(name: String? = nil, code: String? = nil) {
        self.name = name
        self.code = code
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.name, forKey: .name)
        try container.encodeIfPresent(self.code, forKey: .code)
    }
    
    enum CodingKeys: CodingKey {
        case name
        case code
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.name = try container.decodeIfPresent(String.self, forKey: .name)
        self.code = try container.decodeIfPresent(String.self, forKey: .code)
    }
}

